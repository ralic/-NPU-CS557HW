/*
 * Student Info: Name=Lo,WeiShun , ID= 13108
 * Subject: CourseNo_HWNo_Summer_2015
 * Author: raliclo
 * Filename: hp.js.js
 * Date and Time: Feb 21, 2016 3:56:50 PM
 * Project Name: CS557-HW3-13108-Weishun
 */

window.onload = function () {

};
