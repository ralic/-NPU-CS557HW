/* 
 * Student Info: Name=Lo,WeiShun , ID= 13108
 * Subject: CourseNo_HWNo_Summer_2015
 * Author: raliclo
 * Filename: gulpfile.js
 * Date and Time: Jan 25, 2016 3:34:18 PM
 * Project Name: CS557-HW1-13108-Weishun
 */

var gulp = require('gulp');

gulp.task('default', function () {
    // place code for your default task here
});
