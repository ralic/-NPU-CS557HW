/* 
 * Student Info: Name=Lo,WeiShun , ID= 13108
 * Subject: CourseNo_HWNo_Summer_2015
 * Author: raliclo
 * Filename: Gruntfile.js
 * Date and Time: Jan 25, 2016 3:34:17 PM
 * Project Name: CS557-HW1-13108-Weishun
 */
module.exports = function (grunt) {
    // Project configuration.
    grunt.initConfig({
    });
};
