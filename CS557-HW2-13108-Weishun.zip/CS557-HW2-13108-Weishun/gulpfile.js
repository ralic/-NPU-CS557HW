/* 
 * Student Info: Name=Lo,WeiShun , ID= 13108
 * Subject: CourseNo_HWNo_Summer_2015
 * Author: raliclo
 * Filename: gulpfile.js
 * Date and Time: Feb 3, 2016 4:25:27 PM
 * Project Name: HTML5Application
 */

var gulp = require('gulp');

gulp.task('default', function () {
    // place code for your default task here
});
