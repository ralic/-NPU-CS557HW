/* 
 * Student Info: Name=Lo,WeiShun , ID= 13108
 * Subject: CourseNo_HWNo_Summer_2015
 * Author: raliclo
 * Filename: Gruntfile.js
 * Date and Time: Feb 3, 2016 4:25:27 PM
 * Project Name: HTML5Application
 */
module.exports = function (grunt) {
    // Project configuration.
    grunt.initConfig({
    });
};
